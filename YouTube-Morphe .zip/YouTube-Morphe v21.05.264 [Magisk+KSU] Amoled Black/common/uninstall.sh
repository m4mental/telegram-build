#!/system/bin/sh
{
	MODDIR=${0%/*}
	. "$MODDIR/config"

	rm "/data/adb/YouTube-Morphe/${MODDIR##*/}.apk"
	rmdir "/data/adb/YouTube-Morphe"
	rm "/data/adb/post-fs-data.d/$PKG_NAME-uninstall.sh"
} &

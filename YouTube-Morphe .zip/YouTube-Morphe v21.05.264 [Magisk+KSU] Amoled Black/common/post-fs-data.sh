#!/system/bin/sh

# Clear package cache to force system refresh
rm -rf /data/system/package_cache

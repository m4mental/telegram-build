#!/system/bin/sh

TG_LINK="tg://resolve?domain=AMRGAMAL_STORE"
WEB_LINK="https://t.me/AMRGAMAL_STORE"

if pm list packages | grep -q "org.telegram.messenger"; then
    am start -a android.intent.action.VIEW -d "$TG_LINK" >/dev/null 2>&1
else
    am start -a android.intent.action.VIEW -d "$WEB_LINK" >/dev/null 2>&1
fi
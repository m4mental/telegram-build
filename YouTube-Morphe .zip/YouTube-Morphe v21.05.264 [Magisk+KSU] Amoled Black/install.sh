##################
# Config Flags
##################

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

##################
# Vars
##################

ANDROID_VER="$(getprop ro.build.version.release)"
SDK="$(getprop ro.build.version.sdk)"
CODENAME="$(getprop ro.build.version.codename)"
ARCH="$(getprop ro.product.cpu.abi)"
SAR="$(getprop ro.build.system_root_image)"
SEC_PATCH="$(getprop ro.build.version.security_patch)"

KERNEL="$(uname -r)"
CPU="$(getprop ro.hardware)"
PROC="$(getprop ro.product.board)"
SOC_MODEL="$(getprop ro.soc.model)"
MANUFACTURE="$(getprop ro.product.manufacturer)"
DEVICE="$(getprop ro.product.device)"
MODEL="$(getprop ro.product.model)"
BRAND="$(getprop ro.product.brand)"
SYSTEM_MODEL_FILE="$(grep -m1 '^ro.product.system.model=' /system/build.prop | cut -d= -f2)"
DEVICE_MODEL="${SYSTEM_MODEL_FILE:-Unknown}"
SYSTEM_FS=$(grep -E ' /system | /system_root | / ' /proc/mounts | head -n 1 | awk '{print $3}')

if [ "$SYSTEM_FS" = "erofs" ]; then
    ACCESS="Read-Only"
else
    ACCESS="Read-Write"
fi

MODNAME="$(grep_prop name $TMPDIR/module.prop)"
MODVER="$(grep_prop version $TMPDIR/module.prop)"
AUTHOR="$(grep_prop author $TMPDIR/module.prop)"
MODDESC="$(grep_prop description $TMPDIR/module.prop)"
SUPPORT_LINK="$(grep_prop support $TMPDIR/module.prop)"
SELINUX_STATUS="$(getenforce 2>/dev/null || echo Unknown)"

##################
# Storage Info
##################

RAW_DATA=$(df -k /data 2>/dev/null | tail -n 1)

DATA_TOTAL_KB=$(echo "$RAW_DATA" | awk '{print $2}')
DATA_USED_KB=$(echo "$RAW_DATA" | awk '{print $3}')

[ -z "$DATA_TOTAL_KB" ] && DATA_TOTAL_KB=0
[ -z "$DATA_USED_KB" ] && DATA_USED_KB=0

DATA_TOTAL_MB=$((DATA_TOTAL_KB / 1024))
DATA_USED_MB=$((DATA_USED_KB / 1024))

STORAGE_TOTAL_LABEL="Unknown"
if [ "$DATA_TOTAL_MB" -lt 1024 ]; then
  STORAGE_TOTAL_LABEL="${DATA_TOTAL_MB}MB"
elif [ "$DATA_TOTAL_MB" -le 80000 ]; then
  STORAGE_TOTAL_LABEL="64GB"
elif [ "$DATA_TOTAL_MB" -le 150000 ]; then
  STORAGE_TOTAL_LABEL="128GB"
elif [ "$DATA_TOTAL_MB" -le 300000 ]; then
  STORAGE_TOTAL_LABEL="256GB"
elif [ "$DATA_TOTAL_MB" -le 600000 ]; then
  STORAGE_TOTAL_LABEL="512GB"
elif [ "$DATA_TOTAL_MB" -le 1200000 ]; then
  STORAGE_TOTAL_LABEL="1TB"
else
  STORAGE_TOTAL_LABEL="$((DATA_TOTAL_MB / 1024))GB"
fi

if [ "$DATA_USED_MB" -lt 1024 ]; then
  STORAGE_USED_LABEL="${DATA_USED_MB}MB"
else
  STORAGE_USED_LABEL="$((DATA_USED_MB / 1024))GB"
fi

##################
# RAM Info
##################

RAM_TOTAL="$(free -m | awk '/Mem/ {print $2}')"
RAM_FREE="$(free -m | awk '/Mem/ {print $7}')"

RAM_LABEL="Unknown"
if   [ "$RAM_TOTAL" -le 2500 ]; then
  RAM_LABEL="2GB"
elif [ "$RAM_TOTAL" -le 3500 ]; then
  RAM_LABEL="3GB"
elif [ "$RAM_TOTAL" -le 4500 ]; then
  RAM_LABEL="4GB"
elif [ "$RAM_TOTAL" -le 6500 ]; then
  RAM_LABEL="6GB"
elif [ "$RAM_TOTAL" -le 8500 ]; then
  RAM_LABEL="8GB"
elif [ "$RAM_TOTAL" -le 13000 ]; then
  RAM_LABEL="12GB"
elif [ "$RAM_TOTAL" -le 17000 ]; then
  RAM_LABEL="16GB"
elif [ "$RAM_TOTAL" -le 34000 ]; then
  RAM_LABEL="32GB"
else
  RAM_LABEL="$((RAM_TOTAL / 1024))GB"
fi

if [ "$RAM_FREE" -lt 1024 ]; then
  RAM_FREE_LABEL="${RAM_FREE}MB"
elif [ "$RAM_FREE" -le 2500 ]; then
  RAM_FREE_LABEL="2GB"
elif [ "$RAM_FREE" -le 3500 ]; then
  RAM_FREE_LABEL="3GB"
elif [ "$RAM_FREE" -le 4500 ]; then
  RAM_FREE_LABEL="4GB"
elif [ "$RAM_FREE" -le 6500 ]; then
  RAM_FREE_LABEL="6GB"
elif [ "$RAM_FREE" -le 8500 ]; then
  RAM_FREE_LABEL="8GB"
elif [ "$RAM_FREE" -le 13000 ]; then
  RAM_FREE_LABEL="12GB"
elif [ "$RAM_FREE" -le 17000 ]; then
  RAM_FREE_LABEL="16GB"
elif [ "$RAM_FREE" -le 34000 ]; then
  RAM_FREE_LABEL="32GB"
else
  RAM_FREE_LABEL="$((RAM_FREE / 1024))GB"
fi

##################
# Battery Info
##################

BAT_DESIGN=0
BAT_CURRENT=0

for p in \
/sys/class/power_supply/battery \
/sys/class/power_supply/BAT0 \
/sys/class/power_supply/bms \
/sys/class/power_supply/max170xx_battery; do

  [ -d "$p" ] || continue

  if [ "$BAT_DESIGN" -eq 0 ]; then
    [ -f "$p/charge_full_design" ] && BAT_DESIGN=$(cat "$p/charge_full_design")
    [ -z "$BAT_DESIGN" ] && [ -f "$p/energy_full_design" ] && BAT_DESIGN=$(cat "$p/energy_full_design")
  fi

  if [ "$BAT_CURRENT" -eq 0 ]; then
    [ -f "$p/charge_full" ] && BAT_CURRENT=$(cat "$p/charge_full")
    [ -z "$BAT_CURRENT" ] && [ -f "$p/energy_full" ] && BAT_CURRENT=$(cat "$p/energy_full")
  fi

  [ "$BAT_DESIGN" -gt 0 ] && [ "$BAT_CURRENT" -gt 0 ] && break
done

[ "$BAT_DESIGN" -gt 100000 ] && BAT_DESIGN=$((BAT_DESIGN / 1000))
[ "$BAT_CURRENT" -gt 100000 ] && BAT_CURRENT=$((BAT_CURRENT / 1000))

if [ "$BAT_DESIGN" -gt 0 ] && [ "$BAT_CURRENT" -gt 0 ]; then
  BAT_HEALTH=$(( BAT_CURRENT * 100 / BAT_DESIGN ))
  BATTERY_CAPACITY="${BAT_DESIGN}mAh"
  BATTERY_HEALTH="${BAT_HEALTH}%"
else
  BATTERY_CAPACITY="Unknown"
  BATTERY_HEALTH="Unknown"
fi

##################
# Display Info
##################

SCREEN_RES="$(wm size 2>/dev/null | awk -F': ' '{print $2; exit}')"

SCREEN_W=$(echo "$SCREEN_RES" | cut -d'x' -f1)
SCREEN_H=$(echo "$SCREEN_RES" | cut -d'x' -f2)

SCREEN_W=${SCREEN_W:-0}
SCREEN_H=${SCREEN_H:-0}

if [ "$SCREEN_W" -gt "$SCREEN_H" ]; then
    MAX_RES="$SCREEN_W"
else
    MAX_RES="$SCREEN_H"
fi

RES_LABEL="Unknown"
if [ "$MAX_RES" -ge 3840 ]; then
    RES_LABEL="4K"
elif [ "$MAX_RES" -ge 2560 ]; then
    RES_LABEL="2K / QHD"
elif [ "$MAX_RES" -ge 2340 ]; then
    RES_LABEL="FHD+"
elif [ "$MAX_RES" -ge 1920 ]; then
    RES_LABEL="FHD"
elif [ "$MAX_RES" -ge 1600 ]; then
    RES_LABEL="HD+"
elif [ "$MAX_RES" -ge 1280 ]; then
    RES_LABEL="HD"
fi

SCREEN_DENSITY="$(wm density 2>/dev/null | awk -F': ' '{print $2; exit}')"
SCREEN_DENSITY="${SCREEN_DENSITY:-Unknown}"

MAX_RR="$(dumpsys display 2>/dev/null \
  | grep -m1 'peakRefreshRate' \
  | sed 's/.*peakRefreshRate=\([0-9.]*\).*/\1/' \
  | awk '{printf "%.0f", $1}')"

MAX_RR="${MAX_RR:-Unknown}"

GPU_INFO="$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES:')"
GPU_INFO="${GPU_INFO#*GLES: }"

GPU_VENDOR="$(echo "$GPU_INFO" | cut -d',' -f1 | xargs)"
GPU_MODEL="$(echo "$GPU_INFO" | cut -d',' -f2 | xargs)"
GPU_OPENGL="$(echo "$GPU_INFO" | grep -o 'OpenGL ES [0-9]\.[0-9]')"

##################
# Greetings
##################

DATE_TIME="$(date '+%A | %d %B %Y | %I:%M %p')"
TIME="$(date '+%d, %b - %I:%M %p')"
HOUR=$(date +%H)

TZ=$(getprop persist.sys.timezone)
[ -z "$TZ" ] && TZ=$(getprop ro.boot.timezone)
[ -z "$TZ" ] && TZ=$(getprop ro.config.timezone)

if echo "$TZ" | grep -q "/"; then
    CITY=$(echo "$TZ" | cut -d'/' -f2 | tr '_' ' ')
else
    CITY=""
fi

case "$CITY" in
  ""|UTC|GMT*|Etc*)
    CITY="YOUR REGION"
    ;;
esac

if [ "$HOUR" -ge 5 ] && [ "$HOUR" -lt 12 ]; then
    GREETING="GOOD MORNING 🌞☕"
elif [ "$HOUR" -ge 12 ] && [ "$HOUR" -lt 17 ]; then
    GREETING="GOOD AFTERNOON 🌤️🙂"
elif [ "$HOUR" -ge 17 ] && [ "$HOUR" -lt 21 ]; then
    GREETING="GOOD EVENING ✨🥰"
else
    GREETING="GOOD NIGHT 🥱😴"
fi

##################
# Android Name
##################

if [ "$SDK" -eq 21 ]; then
    ANDROID_NAME="Lollipop"
elif [ "$SDK" -eq 22 ]; then
    ANDROID_NAME="Lollipop"
elif [ "$SDK" -eq 23 ]; then
    ANDROID_NAME="Marshmallow"
elif [ "$SDK" -eq 24 ]; then
    ANDROID_NAME="Nougat"
elif [ "$SDK" -eq 25 ]; then
    ANDROID_NAME="Nougat"
elif [ "$SDK" -eq 26 ]; then
    ANDROID_NAME="Oreo"
elif [ "$SDK" -eq 27 ]; then
    ANDROID_NAME="Oreo"
elif [ "$SDK" -eq 28 ]; then
    ANDROID_NAME="Pie"
elif [ "$SDK" -eq 29 ]; then
    ANDROID_NAME="Quince Tart"
elif [ "$SDK" -eq 30 ]; then
    ANDROID_NAME="Red Velvet Cake"
elif [ "$SDK" -eq 31 ]; then
    ANDROID_NAME="Snow Cone"
elif [ "$SDK" -eq 32 ]; then
    ANDROID_NAME="Snow Cone"
elif [ "$SDK" -eq 33 ]; then
    ANDROID_NAME="Tiramisu"
elif [ "$SDK" -eq 34 ]; then
    ANDROID_NAME="Upside Down Cake"
elif [ "$SDK" -eq 35 ]; then
    ANDROID_NAME="Vanilla Ice Cream"
elif [ "$SDK" -eq 36 ]; then
    ANDROID_NAME="Baklava"
elif [ "$SDK" -eq 37 ]; then
    ANDROID_NAME="Cinnamon Bun"
else
    ANDROID_NAME="null"
fi

##################
# UI Function
##################

PRINT_DONE=0
UI_DELAY=0.05

p() {
  ui_print "$1"
  sleep "$UI_DELAY"
}

print_modname() {
  [ "$PRINT_DONE" -eq 1 ] && return
  PRINT_DONE=1
  
p " "
p "__   __        _____     _"
p "\ \ / /       |_   _|   | |"
p " \ V /___  _   _| |_   _| |__   ___"
p "  \ // _ \| | | | | | | | '_ \ / _ \\"
p "  | | (_) | |_| | | |_| | |_) |  __/"
p "  \_/\___/ \__,_\_/\__,_|_.__/ \___|"
p ""
p "___  ___                 _"
p "|  \/  |                | |"
p "| .  . | ___  _ __ _ __ | |__   ___"
p "| |\/| |/ _ \| '__| '_ \| '_ \ / _ \\"
p "| |  | | (_) | |  | |_) | | | |  __/"
p "\_|  |_/\___/|_|  | .__/|_| |_|\___|"
p "                  | |"
p "                  |_|"

p " "

p "-------------------------------------"

p "-              LET'S GO             -"

p "-------------------------------------"

p " "

p "- HELLO BROTHER, $GREETING"

p " "

p "- $DATE_TIME"

p " "

p "- PROUD TO SEE A USER FROM | $CITY 🥰"

p " "

p "-------------------------------------"

p "-           ROOT DETECTION          -"

p "-------------------------------------"

p " "

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
p "- PROVIDER       : KernelSU App"
p "- VERSION        : $KSU_VER"
p "- VERSION CODE   : $KSU_VER_CODE"
p "- KERNEL VERSION : $KSU_KERNEL_VER_CODE"

elif [ "$BOOTMODE" ] && [ "$APATCH" ]; then
p "- PROVIDER     : APatch App"
p "- VERSION      : $APATCH_VER"
p "- VERSION CODE : $APATCH_VER_CODE"

elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
p "- PROVIDER     : Magisk App"
p "- VERSION      : $MAGISK_VER"
p "- VERSION CODE : $MAGISK_VER_CODE"

fi

p " "

p "-------------------------------------"

p "-           MODULE INFO             -"

p "-------------------------------------"

p " "

p "- AUTHOR   : $AUTHOR"

p "- MODULE   : $MODNAME"

p "- VERSION  : $MODVER"

p "- TELEGRAM : $SUPPORT_LINK"

p " "

p "-------------------------------------"

p "-           DEVICE INFO             -"

p "-------------------------------------"

p " "

[ -n "$DEVICE_MODEL" ] && p "- DEVICE MODEL   : $DEVICE_MODEL"

p "- MANUFACTURE    : $MANUFACTURE"

p "- BRAND          : $BRAND"

p "- DEVICE         : $DEVICE"

p "- MODEL          : $MODEL"

p "- PROC           : $PROC"

p "- SoC            : $SOC_MODEL"

p "- CPU            : $CPU"

p "- KERNEL         : $KERNEL"

p "- RAM            : ${RAM_FREE_LABEL} available | ${RAM_LABEL} total"

p "- STORAGE        : $STORAGE_USED_LABEL used | $STORAGE_TOTAL_LABEL total"

p "- SYSTEM FS      : ${SYSTEM_FS:-Unknown} | $ACCESS"

p "- BATTERY        : $BATTERY_CAPACITY | HEALTH $BATTERY_HEALTH"

p "- ANDROID        : $ANDROID_VER $CODENAME (SDK $SDK) $ARCH"

p "- ANDROID NAME   : $ANDROID_NAME"

p "- SELinux STATUS : $SELINUX_STATUS"

p "- SECURITY PATCH : $SEC_PATCH"

p " "

p "-------------------------------------"

p "-           DISPLAY INFO            -"

p "-------------------------------------"

p " "

p "- RESOLUTION     : ${SCREEN_RES:-Unknown} | ${RES_LABEL:-Unknown}"

p "- DENSITY        : ${SCREEN_DENSITY:-Unknown} (DPI)"

p "- REFRESH RATE   : ${MAX_RR:-Unknown}Hz"

p "- GPU VENDOR     : ${GPU_VENDOR:-Unknown}"

p "- GPU MODEL      : ${GPU_MODEL:-Unknown}"

p "- OpenGL VERSION : ${GPU_OPENGL:-Unknown}"

p " "

p "-------------------------------------"

p "-           INSTALLATIONS           -"

p "-------------------------------------"

p " "

p "- Installing : $MODNAME"

p "- Install at : $TIME"

}

##################
# Copy essential files
##################

cp -af $TMPDIR/Banner.png $MODPATH/Banner.png
cp -af $TMPDIR/action.sh $MODPATH/action.sh
cp -af $TMPDIR/base.apk $MODPATH/base.apk
cp -af $TMPDIR/com.google.android.youtube.apks $MODPATH/com.google.android.youtube.apks
cp -af $TMPDIR/config $MODPATH/config
cp -af $TMPDIR/uninstall.sh $MODPATH/uninstall.sh
unzip -o "$ZIPFILE" 'bin/*' -d $TMPDIR >&2

##########################
# Load config
##########################
print_modname

. "$MODPATH/config"

##########################
# Setup ARCH
##########################
if [ "$ARCH" = "arm" ] || [ "$ARCH" = "armeabi-v7a" ]; then
    BIN_ARCH="arm"; ARCH_LIB="armeabi-v7a"
elif [ "$ARCH" = "arm64" ] || [ "$ARCH" = "arm64-v8a" ]; then
    BIN_ARCH="arm64"; ARCH_LIB="arm64-v8a"
elif [ "$ARCH" = "x86" ]; then
    BIN_ARCH="x86"; ARCH_LIB="x86"
elif [ "$ARCH" = "x64" ] || [ "$ARCH" = "x86_64" ]; then
    BIN_ARCH="x64"; ARCH_LIB="x86_64"
else
    abort "ERROR: unreachable ARCH: $ARCH"
fi

##########################
# Prepare cmpr tool
##########################
CMPR="$TMPDIR/bin/$BIN_ARCH/cmpr"
[ ! -f "$CMPR" ] && abort "ERROR: $CMPR not found!"
chmod 0755 "$CMPR" || abort "ERROR: chmod failed for cmpr"

set_permissions() {
    set_perm_recursive "$TMPDIR/bin" 0 0 0755 0755
}

##########################
# Setup mm & pmex
##########################
if su -M -c true >/dev/null 2>&1; then
    alias mm='su -M -c'
else
    alias mm='nsenter -t1 -m'
fi

pmex() {
    OP=$(pm "$@" 2>&1 </dev/null)
    RET=$?
    echo "$OP"
    return $RET
}

##########################
# Unmount old binds
##########################
mm grep -F "$PKG_NAME" /proc/mounts | while read -r line; do
    ui_print "- Un-mount"
    mp=${line#* } mp=${mp%% *}
    mm umount -l "${mp%%\\*}"
done
am force-stop "$PKG_NAME"

##########################
# Prepare APKS bundle
##########################
APKS_FILE="$TMPDIR/$PKG_NAME.apks"
APKS_DIR="$TMPDIR/apks"

mkdir -p "$APKS_DIR" || abort "ERROR: Failed to create apks dir"
unzip -o -qq "$APKS_FILE" -d "$APKS_DIR" >/dev/null 2>&1 || abort "ERROR: Failed to unzip APKS bundle"

APK_LIST=""
for f in "$APKS_DIR"/*.apk; do
    [ -f "$f" ] && APK_LIST="$APK_LIST $f"
done
[ -z "$APK_LIST" ] && abort "ERROR: No APKs found inside bundle"

ui_print "- Installing YouTube APKS Bundle"

##########################
# Version check & cmpr check
##########################
INS=true
CUR_VER=""
BASEPATH=$(pmex path "$PKG_NAME" | grep base.apk 2>/dev/null)

if [ -n "$BASEPATH" ]; then
    BASEPATH=${BASEPATH##*:}
    BASEPATH=${BASEPATH%/*}

    CUR_VER=$(dumpsys package "$PKG_NAME" | grep -m1 versionName)
    CUR_VER=${CUR_VER#*=}
    ui_print "- Installed version: $CUR_VER"

    # identical base.apk → skip install
    if "$CMPR" "$BASEPATH/base.apk" "$MODPATH/base.apk"; then
        ui_print "- base.apk identical, skipping install"
        INS=false
    fi
fi

NEW_VER="$PKG_VER"
ui_print "- Module version: $NEW_VER"

if [ "$INS" = true ]; then
    
    if [ "$CUR_VER" = "$NEW_VER" ]; then
        ui_print "- Same version detected, skipping install"
        INS=false

    elif [ "$CUR_VER" \> "$NEW_VER" ]; then
        if [ "${BASEPATH:1:4}" != "data" ]; then

            mkdir -p /data/adb/YouTube-Morphe/empty /data/adb/post-fs-data.d
            SCNM="/data/adb/post-fs-data.d/$PKG_NAME-uninstall.sh"
            echo "mount -o bind /data/adb/YouTube-Morphe/empty $BASEPATH" >"$SCNM"
            chmod +x "$SCNM"
            ui_print "- Created uninstall script for system app downgrade"
            abort "- Reboot and reflash the module!"
        else
            ui_print "- Downgrade detected, uninstalling old version"
            pmex uninstall -k --user 0 "$PKG_NAME" >/dev/null 2>&1 || :
            INS=true
        fi
    fi
fi

##########################
# Install APKS bundle
##########################
if [ "$INS" = true ]; then
    VERIF_ADB=$(settings get global verifier_verify_adb_installs)
    
    settings put global verifier_verify_adb_installs 0

    TOTAL_SIZE=0
    for a in $APK_LIST; do
        SZ=$(stat -c "%s" "$a")
        TOTAL_SIZE=$((TOTAL_SIZE + SZ))
    done

    SES=$(pmex install-create --user 0 -r -d -S "$TOTAL_SIZE") || abort "ERROR: install-create failed"
    SES=${SES#*[} SES=${SES%]*}

    IDX=0
    for a in $APK_LIST; do
        pmex install-write "$SES" "$IDX.apk" "$a" >/dev/null 2>&1 || abort "ERROR: install-write failed for $(basename "$a")"
        IDX=$((IDX + 1))
    done

    pmex install-commit "$SES" >/dev/null 2>&1 || abort "ERROR: install-commit failed"
    
BASEPATH=$(pmex path "$PKG_NAME" | grep base.apk) || abort "ERROR: can't get base.apk path after install"
BASEPATH=${BASEPATH##*:}
BASEPATH=${BASEPATH%/*}
    
    settings put global verifier_verify_adb_installs "$VERIF_ADB"
fi

##########################
# Extract native libs
##########################

ui_print "- Extracting Native Libs From Bundle APKs"

TMP_LIB="$TMPDIR/libtmp"
rm -rf "$TMP_LIB"
mkdir -p "$TMP_LIB"

for apk in $APK_LIST; do
    unzip -o "$apk" "lib/$ARCH_LIB/*.so" -d "$TMP_LIB" >/dev/null 2>&1 || :
done

[ -d "$TMP_LIB/lib/$ARCH_LIB" ] || ui_print "! No native libs for $ARCH_LIB"

mkdir -p "$BASEPATH/lib/$ARCH_LIB"
cp -af "$TMP_LIB/lib/$ARCH_LIB/"*.so "$BASEPATH/lib/$ARCH_LIB/" 2>/dev/null || :

set_perm_recursive "${BASEPATH}/lib" 1000 1000 755 755 u:object_r:apk_data_file:s0

##########################
# Mount base.apk
##########################
ui_print "- Mounting YouTube Morphe"
mkdir -p "/data/adb/YouTube-Morphe"
Morphe=/data/adb/YouTube-Morphe/${MODPATH##*/}.apk
mv -f "$MODPATH/base.apk" "$Morphe"
set_perm "$Morphe" 1000 1000 644 u:object_r:apk_data_file:s0

if ! op=$(mm mount -o bind "$Morphe" "$BASEPATH/base.apk" 2>&1); then
    ui_print "ERROR: Mount failed!"
    ui_print "$op"
fi

am force-stop "$PKG_NAME"
ui_print "- Optimizing YouTube Morphe"
nohup cmd package compile --reset "$PKG_NAME" >/dev/null 2>&1 &

##########################
# Cleanup
##########################
rm -rf "${MODPATH:?}/bin" "$MODPATH/$PKG_NAME.apks" "$APKS_DIR"
